package org.example;
import java.util.Objects;
import java.util.Scanner;

public class Calc {


    static void myCalc() {
        Scanner scnr = new Scanner(System.in);
        System.out.println("Welcome to the Calculator App! " +  "Insert your first number");
        double x = scnr.nextDouble();
        System.out.println("insert your next number");
        double y = scnr.nextDouble();
        System.out.println(" now " +  "insert your last number");
        double z = scnr.nextDouble();
        System.out.println("For the operation order of " +x+ " "+y+ " " +z+ " use add, sub, multi, or divide");
        scnr.nextLine();
        System.out.println("For the operation order of " +z+ " "+x+ " " +y+ " use divide2");
        String MathOperator = scnr.nextLine();
        System.out.println(MathOperator);
        double UserResult = 0;
        switch(MathOperator) {
            case "add":
                UserResult = x + y + z;
                break;

            case "sub":
                UserResult = x - y - z;
                break;

            case "multi":
                UserResult = x * y * z;
                break;

            case "divide":
                UserResult = x / y / z;
                break;

            case "divide2":
                UserResult = z / x / y;
                break;
            default:
                System.out.println("Incorrect Input! options are add,sub,multi,divide");
        }
        System.out.println(" Here's your Result for your inputs: " + String.format("%.2f", UserResult));
    }
    static void LetsContinue(){
        System.out.println("Would you like to do another calculation? if yes insert Y");
        Scanner scnr = new Scanner(System.in);
        String decide = scnr.nextLine();
        if (Objects.equals(decide, "Y")) {
            myCalc();
        } else {
            System.out.println("Have a Great Day!");
        }
    }
}
