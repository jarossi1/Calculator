package org.example;

import java.util.Scanner;

import static org.example.Calc.LetsContinue;
import static org.example.Calc.myCalc;

public class Main {
    public static void main(String[] args){
        Scanner scnr = new Scanner(System.in);
        myCalc();
        LetsContinue();
    }
}